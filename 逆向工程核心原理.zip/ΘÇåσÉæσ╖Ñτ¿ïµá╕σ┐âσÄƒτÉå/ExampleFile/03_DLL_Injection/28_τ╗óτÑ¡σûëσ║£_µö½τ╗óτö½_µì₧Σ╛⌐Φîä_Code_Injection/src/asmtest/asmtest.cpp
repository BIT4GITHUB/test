#include "stdio.h"

int test()
{
    return 0;
}

int main(int argc, char* argv[])
{
    return test();
}